// Copyright (c) Evolus Solutions. All rights reserved.
// License: GPL/MPL
// $Id$

function AbstractSymbol() {
    this.namespace = null;
    this.id = null;
    this.displayName = null;
}
